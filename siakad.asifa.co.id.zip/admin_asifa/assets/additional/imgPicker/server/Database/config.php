<?php

return array(
	// Database name
	'database'  => 'imgpicker',
	
	// Database username
	'username'  => 'root',
	
	// Database password
	'password'  => 'hani',

	//Database hostname
	'hostname'  => 'localhost',

	// Advanced options
	'prefix'    => '',
	'driver'    => 'mysql',
	'charset'   => 'utf8',
	'collation' => 'utf8_unicode_ci',
);