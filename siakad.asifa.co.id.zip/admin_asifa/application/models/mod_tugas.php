<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class mod_tugas extends MY_Model
{

}