<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


/*
|--------------------------------------------------------------------------
| File Upload
|--------------------------------------------------------------------------
*/
$config['file_img_path'] = 'assets/avatar/';
$config['file_img_dir'] = FCPATH.$config['file_img_path'];

/*
|--------------------------------------------------------------------------
| Misc
|--------------------------------------------------------------------------
*/
$config['max_failed_login_attempts'] = 5;
$config['delay_failed_login_attempts'] = 18000;


?>