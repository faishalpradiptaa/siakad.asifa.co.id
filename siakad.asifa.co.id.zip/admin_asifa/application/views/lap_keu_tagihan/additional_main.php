<script type="text/javascript" src="<?php echo base_url(); ?>assets/custom/js/autoNumeric-min.js"></script>

<script>
	var TAKE_OVER = true; // take over init my_table
	
	var my_table = $("#datatable-main").myTable();	
	
</script>