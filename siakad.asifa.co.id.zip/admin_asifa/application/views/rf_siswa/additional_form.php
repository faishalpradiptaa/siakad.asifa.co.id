<style>
	.modal-body .tab-container .nav.nav-tabs{display:none;}
	
</style>