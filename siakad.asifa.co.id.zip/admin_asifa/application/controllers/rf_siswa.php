<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class rf_siswa extends crud_controller {

	public $title = 'Siswa';
	public $column = array //tabel
	(
		'tahun_lahir' => array(
			'title' => 'Tahun Lahir',
			'filter' => 'text',
			'width' => '10%',
			'attribut' => array('data-class' => 'text-center'),
		),
		'no_induk' => array(
			'title' => 'No.Induk',
			'filter' => 'text',
			'width' => '10%'
		),
		'nisn' => array(
			'title' => 'NISN',
			'filter' => 'text',
			'width' => '10%'
		),
		'nama' => array(
			'title' => 'Nama',
			'filter' => 'text',
		),
		'jk' => array(
			'title' => 'Jenis Kelamin',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'kota_lahir' => array(
			'title' => 'Tempat Lahir',
			'attribut' => array('data-visible' => 'false'),
		),
		'tgl_lahir' => array(
			'title' => 'Tgl Lahir',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'alamat' => array(
			'title' => 'Alamat',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'nama_ayah' => array(
			'title' => 'Nama Ayah',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'telp_ayah' => array(
			'title' => 'Telp Ayah',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'nama_ibu' => array(
			'title' => 'Nama Ibu',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'telp_ibu' => array(
			'title' => 'Telp Ibu',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'nama_telp_darurat' => array(
			'title' => 'Nama Telp Darurat',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'telp' => array(
			'title' => 'Telp',
			'filter' => 'text',
			'width' => '10%'
		),
		'tgl_masuk' => array(
			'title' => 'Tgl Masuk',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'nama_status' => array(
			'title' => 'Status',
			'filter' => 'text',
			'width' => '10%',
			'attribut' => array('data-class' => 'text-center'),
		),
		'angkatan' => array(
			'title' => 'Angkatan1',
			'filter' => 'text',
			'width' => '10%',
			'attribut' => array('data-class' => 'text-center'),
		),
		'nama_agama' => array(
			'title' => 'Agama',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'email' => array(
			'title' => 'Email',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'last_login' => array(
			'title' => 'Terakhir Login',
			'filter' => 'text',
			'attribut' => array('data-visible' => 'false'),
		),
		'options-no-db' => array(
			'title' => 'Option',
			'width' => '10%',
			'attribut' => array('data-class' => 'text-center', 'data-sortable' => 'false'),
		)
	);
	public $form_data = array( //form
		'tahun_lahir' => array(
			'title' => 'Tahun Lahir',
			'type' => 'number',
			'col_width' => 'col-sm-4',
			'validate' => 'required',
		),
		'no_induk' => array(
			'title' => 'No.Induk',
			'type' => 'text',
			'col_width' => 'col-sm-5',
			'validate' => 'required;code',
		),
		'nisn' => array(
			'title' => 'NISN',
			'type' => 'text',
			'col_width' => 'col-sm-5',
		),
		'nama' => array(
			'title' => 'Nama',
			'type' => 'text',
			'col_width' => 'col-sm-9',
			'validate' => 'required',
		),
		'jk' => array(
			'title' => 'Jenis Kelamin',
			'type' => 'radio',
			'data' => array( array('value'=>'l','text'=>'Laki-laki'), array('value'=>'p','text'=>'Perempuan') ),
			'col_width' => 'col-sm-9',
			'validate' => 'required',
			'default' => 'l',
		),
		'tempat_lahir' => array(
			'title' => 'Tempat Lahir',
			'type' => 'select',
			'col_width' => 'col-sm-7',
			'validate' => 'required',
		),
		'tgl_lahir' => array(
			'title' => 'Tgl Lahir',
			'type' => 'date',
			'col_width' => 'col-sm-4',
			'validate' => 'required',
		),
		'alamat' => array(
			'title' => 'Alamat',
			'type' => 'text',
			'col_width' => 'col-sm-9',
			'validate' => 'required',
		),
		'nama_ayah' => array(
			'title' => 'Nama Ayah',
			'type' => 'text',
			'col_width' => 'col-sm-8',
		),
		'telp_ayah' => array(
			'title' => 'Telp Ayah',
			'type' => 'text',
			'col_width' => 'col-sm-6',
		),
		'nama_ibu' => array(
			'title' => 'Nama Ibu',
			'type' => 'text',
			'col_width' => 'col-sm-8',
		),
		'telp_ibu' => array(
			'title' => 'Telp Ibu',
			'type' => 'text',
			'col_width' => 'col-sm-6',
		),
		'nama_telp_darurat' => array(
			'title' => 'Nama Telp Darurat',
			'type' => 'text',
			'col_width' => 'col-sm-6',
		),
		'telp' => array(
			'title' => 'Telp',
			'type' => 'text',
			'col_width' => 'col-sm-6',
			'validate' => 'required',
		),
		'tgl_masuk' => array(
			'title' => 'Tgl Masuk',
			'type' => 'date',
			'col_width' => 'col-sm-4',
			'validate' => 'required',
		),
		'status_akademis' => array(
			'title' => 'Status',
			'type' => 'select',
			'col_width' => 'col-sm-4',
			'validate' => 'required',
		),
		'angkatan' => array(
			'title' => 'Angkatan2',
			'type' => 'text',
			'col_width' => 'col-sm-4',
			'validate' => 'required',
		),
		//'jenjang' => array(
		//	'title' => 'Jenjang',
		//	'type' => 'select',
		//	'col_width' => 'col-sm-5',
		//	'validate' => 'required',
	//	),
	//	'sekolah' => array(
	//		'title' => 'Sekolah',
		//	'type' => 'select',
			//'col_width' => 'col-sm-5',
			//'validate' => 'required',
	//	),
	//	'jurusan' => array(
	//		'title' => 'Jurusan',
	//		'type' => 'select',
	//		'col_width' => 'col-sm-5',
	//		'validate' => 'required',
	//	),
	//	'kelas' => array(
	//		'title' => 'Kelas',
	//		'type' => 'select',
	//		'col_width' => 'col-sm-5',
	//		'validate' => 'required',
	//	),
		'agama' => array(
			'title' => 'Agama',
			'type' => 'select',
			'col_width' => 'col-sm-5',
			'validate' => 'required',
		),
		'email' => array(
			'title' => 'Email',
			'type' => 'text',
			'col_width' => 'col-sm-7',
		),
		'password' => array(
			'title' => 'Password',
			'type' => 'password',
			'col_width' => 'col-sm-6',
			'validate' => 'required',
		),
	);
	public $table = 'tb_akd_rf_siswa';
	public $primary_key = 'no_induk';
	public $additional_script_form = 'rf_siswa/additional_form';
	public $view_detail = 'rf_siswa/v_detail';


	// protected CRUD function
	protected function renderTable($kolom, $table, $primary_key)
	{
		$table = $this->db
			->select('tb.*, kt.nama_kota as kota_lahir, ag.nama_agama, st.nama_status')
			->from($table.' tb')
			->join('tb_app_rf_kota kt', 'kt.id_kota = tb.tempat_lahir', 'left')
			->join('tb_app_rf_status st', 'st.kode_status = tb.status_akademis')
			->join('tb_akd_rf_agama ag', 'ag.kode_agama = tb.agama', 'left');

		$data = $this->datatable->render($kolom, $table, $primary_key);
		foreach($data->data as $key => $row)
		{
			// format jk
			$data->data[$key][4] = $row[4] == 'l' ? 'Laki-laki' : 'Perempuan';
			// format tgl lahir
			$data->data[$key][6] = dateMySQL2dateInd($row[6]);
			// format tgl masuk
			$data->data[$key][14] = dateMySQL2dateInd($row[14]);

			$data->data[$key][count($row)-1] = preg_replace('/#main-modal-md/','#main-modal-lg',$row[count($row)-1], 1);
		}
		return $data;
	}

	protected function beforeForm($pack, $id=false)//data buat type "select"
	{
		$this->form_data['tempat_lahir']['data'] = $this->db->select('id_kota as value, nama_kota as text')
		->order_by('nama_kota','ASC')->get('tb_app_rf_kota')->result();
		$this->form_data['status_akademis']['data'] = $this->db->select('kode_status as value, nama_status as text')
		->where('tags like "%siswa%"')->get('tb_app_rf_status')->result();
		$this->form_data['agama']['data'] = $this->db->select('kode_agama as value, nama_agama as text')
		->order_by('nama_agama','ASC')->get('tb_akd_rf_agama')->result();
		//$this->form_data['jenjang']['data'] = $this->db->select('kode_jenjang as value, nama_jenjang as text')
		//->order_by('kode_jenjang','ASC')->get('tb_akd_rf_jenjang')->result();
		//$this->form_data['jurusan']['data'] = $this->db->select('kode_jurusan as value, nama_jurusan as text')
		//->order_by('kode_jurusan','ASC')->get('tb_akd_rf_jurusan')->result();
		//$this->form_data['sekolah']['data'] = $this->db->select('kode_sekolah as value, nama_sekolah as text')
		//->order_by('kode_sekolah','ASC')->get('tb_akd_rf_sekolah')->result();
		//$this->form_data['kelas']['data'] = $this->db->select('kode_kelas as value, nama_kelas as text')
		//->where('kode_thn_ajaran', THN_AJARAN)->order_by('kode_kelas','ASC')->get('tb_akd_rf_kelas')->result();

		if($id)
		{
			$this->form_data['password']['validate'] = '';
		}
		return $pack;
	}

	protected function beforeDetail($pack, $id)
	{
		$this->load->model('mod_siswa');
		$this->load->model('mod_riwayat');
		$this->load->model('mod_tagihan');
		$this->load->model('mod_pembayaran');

		$pack['tahun_ajaran'] = $this->db->where('kode_thn_ajaran', THN_AJARAN)->get('tb_akd_rf_thn_ajaran')->row();
		$pack['akademik'] = $this->mod_siswa->getDetailByNoInduk($id);
		$pack['riwayat'] = $this->mod_riwayat->getDataByNoInduk($id);
		$pack['tagihan'] = $this->mod_tagihan->getDataByNoInduk($id);
		$pack['pembayaran'] = $this->mod_pembayaran->getDataByNoInduk($id);
		return $this->beforeForm($pack, $id);
	}

	protected function beforeSave($data, $id)
	{
		if($id && !$data['password']) unset($data['password']);
		else if($data['password']) $data['password'] =  md5('=a51['.$data['password'].']f4=');
		return $data;
	}


	// public function
	public function autocomplete($limit=10)
	{
		$this->load->model('mod_siswa');
		$result = array(
			"total_count" => $limit,
			"incomplete_results" => false,
			"items" => $this->mod_siswa->getDataAutoComplete($limit),
		);
		echo json_encode($result);
	}

}
